package com.personalai.android.tools
import com.personalai.android.domain.PermissionLevel
import com.personalai.android.rag.RetrievalEngine
import kotlinx.serialization.json.*
class KnowledgeSearchTool(private val retrieval:RetrievalEngine):Tool{
 override val definition=ToolDefinition("knowledge_search","Busca memória e conhecimento local",PermissionLevel.SAFE_READ)
 override suspend fun execute(arguments:JsonObject,context:ToolExecutionContext):ToolResult{
   val q=arguments["query"]?.jsonPrimitive?.contentOrNull?:return ToolResult(false,"Consulta ausente",error="INVALID_ARGUMENT")
   val hits=retrieval.search(q,context.projectId,6); return ToolResult(true,hits.joinToString("
"){"• [${it.type}] ${it.text.take(240)}"})
 }
}
