package com.personalai.android.ai

import com.personalai.android.domain.*
import kotlinx.coroutines.flow.Flow

interface AIProvider {
 val id:String
 val displayName:String
 val capabilities:ProviderCapabilities
 fun streamChat(request:ChatRequest):Flow<ChatChunk>
}
