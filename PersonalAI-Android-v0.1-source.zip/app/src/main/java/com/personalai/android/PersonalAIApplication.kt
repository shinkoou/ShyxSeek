package com.personalai.android

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PersonalAIApplication : Application()
