package com.personalai.android
import com.personalai.android.rag.HashEmbeddingProvider
import kotlin.test.Test
import kotlin.test.assertEquals
class EmbeddingTest { @Test fun dimensions(){ kotlinx.coroutines.runBlocking{ assertEquals(384,HashEmbeddingProvider().embed("Vulkan shader").size) } } }
